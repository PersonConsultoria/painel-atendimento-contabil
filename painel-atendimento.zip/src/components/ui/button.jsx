export const Button = ({ children, ...props }) => <button {...props} className='bg-white border px-3 py-1 rounded'>{children}</button>;
