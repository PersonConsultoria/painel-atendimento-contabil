import PainelAtendimentoPage from './pages/PainelAtendimentoPage';

export default function App() {
  return <PainelAtendimentoPage />;
}